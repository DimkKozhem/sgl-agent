"""
SQL-agent - Система для анализа и оптимизации структуры базы данных
"""

from .api import app

__version__ = "1.0.0"
__all__ = ["app"]

